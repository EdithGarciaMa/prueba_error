Juego de nave espacial

Este juego tiene la funcion de mover la nave de izquierda a derecha unicamente,
y con la tecla de espacio permite disparar a los enemigos que aparecen en la pantalla,
cuando se acierta a los enemigo se produce una explosion con imagen y sonido, y se muestra 
un score con los puntos que se van acumulando.